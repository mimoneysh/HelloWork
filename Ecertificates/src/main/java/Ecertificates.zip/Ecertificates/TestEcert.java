package Ecertificates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestEcert {

	public static void main(String[] args) {
		SpringApplication.run(TestEcert.class, args);
		
		System.out.println("Test E-Certificate");
	}

}
